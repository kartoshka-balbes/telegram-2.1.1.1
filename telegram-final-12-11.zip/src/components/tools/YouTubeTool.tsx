import React, { useState, useEffect, useMemo } from 'react';
import { WorkoutVideo } from './HomeWorkoutsTool';
import {
  ThumbsUp, ThumbsDown, Share2, Download, ListPlus, Flag, MessageSquare, Settings, Play, Pause, Search,
  Home, Zap, Users, History as HistoryIcon, ArrowLeft, X, Bell,
} from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

interface Video {
  id: string;
  title: string;
  channel: string;
  avatarEmoji: string;
  views: string;
  date: string;
  duration: string;
  seconds: number;
  comments: string[];
  workout?: boolean;
  poster: string;
  short?: boolean;
}

const VIDEOS: Video[] = [
  { id: '1', title: 'КАК ВЫЖИТЬ В БОЛОТЕ С ШРЕКОМ (100 ДНЕЙ В HARDFLIP)', channel: 'Влад А4 Бумага', avatarEmoji: '⚡', views: '45 820 100', date: '2 дня назад', duration: '14:20', seconds: 860, comments: ['Вау, крутое видео!', 'А4 топ, остальное фейк', 'Шрек лучший пнг'], poster: 'linear-gradient(135deg,#2d5a1e,#0f2a0a)' },
  { id: '2', title: 'ТЕСТ-ДРАЙВ ТАНКА Т-34 В ГОРОДЕ (РАЗГОН ДО 100 КМ/Ч)', channel: 'AcademeG', avatarEmoji: '🚜', views: '12 450 000', date: '5 дней назад', duration: '22:15', seconds: 1335, comments: ['Костя как всегда гений', 'Гусеница отвалилась на 12 минуте xDD'], poster: 'linear-gradient(135deg,#4a4a2a,#1a1a0a)' },
  { id: '3', title: 'ШОРТС: КАК ПОКОРМИТЬ КОТА ЗА 0.0001 СЕКУНДЫ', channel: 'Кот Борис Official', avatarEmoji: '🐱', views: '99 999 999', date: 'Вчера', duration: '00:15', seconds: 15, comments: ['МЯУ', 'Борис легенда'], poster: 'linear-gradient(135deg,#5a3a1e,#1f1208)', short: true },
  { id: 'w1', title: 'Отжимания от пола: техника и частые ошибки', channel: 'Тренировки для дома', avatarEmoji: '🏋️', views: '3 204 118', date: '3 дня назад', duration: '08:30', seconds: 510, comments: ['Спина прямая, понял', 'Делаю каждое утро', 'После 15 раз руки отваливаются'], workout: true, poster: 'linear-gradient(135deg,#1a2a5a,#0b1230)' },
  { id: 'w2', title: 'Приседания глубокие: полный разбор', channel: 'Тренировки для дома', avatarEmoji: '🏋️', views: '1 870 054', date: 'Неделю назад', duration: '10:05', seconds: 605, comments: ['Колени не болят', 'Пятки не отрывать!'], workout: true, poster: 'linear-gradient(135deg,#2a1a5a,#0f0b30)' },
  { id: 'w3', title: 'Планка на локтях: как продержаться минуту', channel: 'Тренировки для дома', avatarEmoji: '🏋️', views: '5 612 330', date: '2 недели назад', duration: '06:45', seconds: 405, comments: ['Дрожу на 40-й секунде', 'Лучшая планка на ютубе'], workout: true, poster: 'linear-gradient(135deg,#0a3a3a,#07181f)' },
  { id: 'w4', title: 'Скручивания на пресс: 25 повторений без боли в шее', channel: 'Тренировки для дома', avatarEmoji: '🏋️', views: '2 410 900', date: 'Месяц назад', duration: '07:20', seconds: 440, comments: ['Пресс горит'], workout: true, poster: 'linear-gradient(135deg,#5a1a2a,#200a10)' },
  { id: 'w5', title: 'Выпады назад: тренировка ног за 5 минут', channel: 'Тренировки для дома', avatarEmoji: '🏋️', views: '987 400', date: 'Месяц назад', duration: '05:10', seconds: 310, comments: ['Простое упражнение, но работает', 'Утром ноги не слушаются'], workout: true, poster: 'linear-gradient(135deg,#3a2a0a,#1a1204)' },
  { id: 'w6', title: 'ШОРТС: сальто назад за 3 секунды', channel: 'Тренировки для дома', avatarEmoji: '🏋️', views: '14 330 700', date: 'Вчера', duration: '00:30', seconds: 30, comments: ['Невозможно, но выглядит круто'], workout: true, poster: 'linear-gradient(135deg,#5a2a1a,#200f0a)', short: true },
];

const fmtTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

type Tab = 'home' | 'shorts' | 'subs' | 'history';

const Thumb: React.FC<{ v: Video; className?: string }> = ({ v, className = '' }) => (
  <div className={`relative overflow-hidden ${className}`} style={{ background: v.poster }}>
    {v.workout ? (
      <div className="absolute inset-0 opacity-90">
        <WorkoutVideo playing={false} />
      </div>
    ) : (
      <div className="absolute inset-0 flex items-center justify-center text-5xl opacity-80">{v.avatarEmoji}</div>
    )}
    <span className="absolute bottom-1.5 right-1.5 bg-black/80 text-white text-[11px] px-1.5 py-0.5 font-medium">{v.duration}</span>
  </div>
);

export const YouTubeTool: React.FC<ToolProps> = ({ onClose }) => {
  const [tab, setTab] = useState<Tab>('home');
  const [query, setQuery] = useState('');
  const [chip, setChip] = useState<'all' | 'workout' | 'other'>('all');
  const [selected, setSelected] = useState<Video | null>(null);
  const [playing, setPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const [quality, setQuality] = useState('1080p');
  const [speed, setSpeed] = useState(1);
  const [showSettings, setShowSettings] = useState(false);
  const [likes, setLikes] = useState<Record<string, number>>({});
  const [liked, setLiked] = useState<Record<string, boolean>>({});
  const [disliked, setDisliked] = useState<Record<string, boolean>>({});
  const [subs, setSubs] = useState<Record<string, boolean>>({});
  const [history, setHistory] = useState<string[]>([]);
  const [comments, setComments] = useState<Record<string, string[]>>(() => Object.fromEntries(VIDEOS.map((v) => [v.id, [...v.comments]])));
  const [newComment, setNewComment] = useState('');
  const [toast, setToast] = useState<string | null>(null);
  const [imgModal, setImgModal] = useState<string | null>(null);

  const showToast = (t: string) => {
    setToast(t);
    window.setTimeout(() => setToast(null), 2600);
  };

  // ход воспроизведения
  useEffect(() => {
    if (!selected || !playing) return;
    const id = window.setInterval(() => setProgress((p) => Math.min(selected.seconds, p + 0.25 * speed)), 250);
    return () => window.clearInterval(id);
  }, [selected, playing, speed]);

  const open = (v: Video) => {
    soundManager.playBeep(900, 0.05);
    setSelected(v);
    setProgress(0);
    setPlaying(true);
    setShowSettings(false);
    setHistory((h) => [v.id, ...h.filter((x) => x !== v.id)]);
  };

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return VIDEOS.filter((v) => (chip === 'all' ? true : chip === 'workout' ? v.workout : !v.workout)).filter(
      (v) => !q || v.title.toLowerCase().includes(q) || v.channel.toLowerCase().includes(q)
    );
  }, [query, chip]);

  const channels = Array.from(new Set(VIDEOS.map((v) => v.channel)));

  const addComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected || !newComment.trim()) return;
    setComments((c) => ({ ...c, [selected.id]: [newComment.trim(), ...(c[selected.id] || [])] }));
    setNewComment('');
    showToast('Комментарий добавлен');
  };

  const card = (v: Video) => (
    <button key={v.id} onClick={() => open(v)} className="w-full text-left cursor-pointer bg-transparent border-0 p-0 mb-5">
      <Thumb v={v} className="w-full aspect-video" />
      <div className="flex gap-3 mt-2.5 px-3">
        <div className="w-9 h-9 rounded-full bg-[#272727] flex items-center justify-center text-lg shrink-0">{v.avatarEmoji}</div>
        <div className="min-w-0">
          <div className="text-[15px] text-white leading-snug line-clamp-2 font-medium">{v.title}</div>
          <div className="text-[12px] text-[#aaaaaa] mt-0.5">{v.channel} · {v.views} просмотров · {v.date}</div>
        </div>
      </div>
    </button>
  );

  return (
    <div className="fixed inset-0 z-40 bg-[#0f0f0f] text-white flex flex-col select-none">
      {toast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[70] bg-[#f1f1f1] text-[#0f0f0f] px-4 py-2.5 text-[14px] pointer-events-none rounded-lg max-w-[90%]">{toast}</div>
      )}

      {/* Верхняя панель */}
      {!selected && (
        <div className="flex items-center gap-2 px-3 py-2 bg-[#0f0f0f] shrink-0">
          <button onClick={onClose} className="p-2 bg-transparent border-0 cursor-pointer text-white" aria-label="Назад">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-1 shrink-0">
            <span className="w-7 h-5 bg-[#ff0000] rounded-md flex items-center justify-center">
              <Play className="w-3 h-3 fill-white text-white" />
            </span>
            <span className="text-[19px] font-semibold tracking-tight">YouTube</span>
          </div>
          <div className="flex-1" />
          <button onClick={() => showToast('Уведомлений нет')} className="p-2 bg-transparent border-0 cursor-pointer text-white" aria-label="Уведомления">
            <Bell className="w-5 h-5" />
          </button>
          <div className="w-8 h-8 rounded-full bg-[#3ea6ff] text-[#0f0f0f] flex items-center justify-center text-[14px] font-semibold">Я</div>
        </div>
      )}

      {/* Страница видео */}
      {selected ? (
        <div className="flex-1 overflow-y-auto">
          <div className="relative bg-black aspect-video sticky top-0 z-20">
            {selected.workout ? (
              <WorkoutVideo playing={playing} />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center text-6xl" style={{ background: selected.poster }}>{selected.avatarEmoji}</div>
            )}
            <button onClick={() => { setSelected(null); setShowSettings(false); }} className="absolute top-2 left-2 p-2 bg-black/50 text-white border-0 cursor-pointer rounded-full" aria-label="Свернуть">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <button onClick={() => setShowSettings(!showSettings)} className="absolute top-2 right-2 p-2 bg-black/50 text-white border-0 cursor-pointer rounded-full" aria-label="Настройки">
              <Settings className="w-5 h-5" />
            </button>
            <button onClick={() => setPlaying(!playing)} className="absolute inset-0 m-auto w-14 h-14 rounded-full bg-black/50 text-white border-0 cursor-pointer flex items-center justify-center" aria-label="Пауза">
              {playing ? <Pause className="w-7 h-7 fill-white" /> : <Play className="w-7 h-7 fill-white ml-0.5" />}
            </button>
            {showSettings && (
              <div className="absolute top-12 right-2 bg-[#212121] rounded-lg p-3 text-[13px] space-y-2 z-30 min-w-[170px]">
                <div className="flex justify-between gap-3"><span className="text-[#aaaaaa]">Качество</span>
                  <button onClick={() => setQuality(quality === '1080p' ? '4K' : '1080p')} className="bg-transparent border-0 text-white cursor-pointer">{quality}</button></div>
                <div className="flex justify-between gap-3"><span className="text-[#aaaaaa]">Скорость</span>
                  <button onClick={() => setSpeed(speed === 1 ? 2 : speed === 2 ? 0.5 : 1)} className="bg-transparent border-0 text-white cursor-pointer">{speed}x</button></div>
              </div>
            )}
            <div className="absolute bottom-0 left-0 right-0">
              <div className="flex justify-between px-3 text-[12px] text-white mb-1"><span>{fmtTime(progress)} / {selected.duration}</span><span>{quality}</span></div>
              <div className="h-1 bg-white/30 cursor-pointer" onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); setProgress(((e.clientX - r.left) / r.width) * selected.seconds); }}>
                <div className="h-full bg-[#ff0000]" style={{ width: `${(progress / selected.seconds) * 100}%` }} />
              </div>
            </div>
          </div>

          <div className="px-3 py-3">
            <h1 className="text-[18px] leading-snug font-medium">{selected.title}</h1>
            <div className="text-[12px] text-[#aaaaaa] mt-1">{selected.views} просмотров · {selected.date}</div>

            <div className="flex items-center justify-between mt-3">
              <button onClick={() => setImgModal(`Яндекс.Картинки: результаты поиска для «Аватарка канала ${selected.channel}»`)} className="flex items-center gap-3 bg-transparent border-0 cursor-pointer text-left min-w-0">
                <span className="w-10 h-10 rounded-full bg-[#272727] flex items-center justify-center text-xl shrink-0">{selected.avatarEmoji}</span>
                <span className="min-w-0">
                  <span className="block text-[15px] text-white truncate font-medium">{selected.channel}</span>
                  <span className="block text-[12px] text-[#aaaaaa]">{subs[selected.channel] ? 'Вы подписаны' : '1,2 млн подписчиков'}</span>
                </span>
              </button>
              <button
                onClick={() => { setSubs((s) => ({ ...s, [selected.channel]: !s[selected.channel] })); showToast(subs[selected.channel] ? 'Подписка отменена' : `Вы подписались на «${selected.channel}»`); }}
                className={`px-4 py-2 rounded-full text-[14px] font-medium cursor-pointer border-0 ${subs[selected.channel] ? 'bg-[#272727] text-white' : 'bg-white text-[#0f0f0f]'}`}
              >
                {subs[selected.channel] ? 'Вы подписаны' : 'Подписаться'}
              </button>
            </div>

            {/* Действия */}
            <div className="flex gap-2 overflow-x-auto no-scrollbar mt-3 pb-1">
              <div className="flex shrink-0 rounded-full bg-[#272727] overflow-hidden">
                <button
                  onClick={() => { const on = !liked[selected.id]; setLiked((l) => ({ ...l, [selected.id]: on })); setLikes((l) => ({ ...l, [selected.id]: (l[selected.id] || 145000) + (on ? 1 : -1) })); if (on) setDisliked((d) => ({ ...d, [selected.id]: false })); }}
                  className={`flex items-center gap-1.5 px-4 py-2 text-[14px] bg-transparent border-0 cursor-pointer ${liked[selected.id] ? 'text-[#3ea6ff]' : 'text-white'}`}
                >
                  <ThumbsUp className="w-4 h-4" /> {(likes[selected.id] || 145000).toLocaleString('ru-RU')}
                </button>
                <button onClick={() => { setDisliked((d) => ({ ...d, [selected.id]: !d[selected.id] })); setLiked((l) => ({ ...l, [selected.id]: false })); }} className={`px-4 py-2 bg-transparent border-0 border-l border-white/15 cursor-pointer ${disliked[selected.id] ? 'text-[#3ea6ff]' : 'text-white'}`} aria-label="Не нравится">
                  <ThumbsDown className="w-4 h-4" />
                </button>
              </div>
              {[
                [Share2, 'Поделиться', 'Ссылка скопирована в буфер'],
                [Download, 'Скачать', 'Загрузка видео начата'],
                [ListPlus, 'Сохранить', 'Видео добавлено в плейлист'],
                [Flag, 'Пожаловаться', 'Жалоба отправлена модераторам'],
              ].map(([I, label, msg], i) => {
                const Icon = I as React.ElementType;
                return (
                  <button key={i} onClick={() => showToast(msg as string)} className="shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#272727] text-white text-[14px] border-0 cursor-pointer">
                    <Icon className="w-4 h-4" /> {label as string}
                  </button>
                );
              })}
            </div>

            {/* Комментарии */}
            <div className="mt-4 rounded-xl bg-[#1a1a1a] p-3">
              <div className="flex items-center gap-2 text-[15px] font-medium"><MessageSquare className="w-4 h-4" /> Комментарии {(comments[selected.id] || []).length}</div>
              <form onSubmit={addComment} className="flex gap-2 mt-3">
                <input value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="Добавьте комментарий..." className="flex-1 min-w-0 bg-transparent border-0 border-b border-white/30 text-[14px] py-1.5 text-white outline-none placeholder-[#717171]" />
                <button type="submit" className="px-3 text-[14px] bg-[#3ea6ff] text-[#0f0f0f] rounded-full border-0 cursor-pointer font-medium">Отправить</button>
              </form>
              <div className="mt-3 space-y-3 max-h-56 overflow-y-auto">
                {(comments[selected.id] || []).map((c, i) => (
                  <div key={i} className="flex gap-2.5">
                    <span className="w-7 h-7 rounded-full bg-[#3a3a3a] shrink-0" />
                    <div className="text-[14px]">{c}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="text-[15px] font-medium mt-5 mb-3">Рекомендуемые видео</div>
            {VIDEOS.filter((v) => v.id !== selected.id).map(card)}
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto">
          {tab === 'home' && (
            <>
              <div className="px-3 pb-2">
                <div className="flex items-center rounded-full bg-[#222222] px-4 py-2.5">
                  <Search className="w-4 h-4 text-[#aaaaaa] mr-2.5" />
                  <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Введите запрос" className="w-full bg-transparent outline-none text-[15px] text-white placeholder-[#aaaaaa]" />
                  {query && <button onClick={() => setQuery('')} className="bg-transparent border-0 cursor-pointer text-white p-0"><X className="w-4 h-4" /></button>}
                </div>
              </div>
              <div className="flex gap-2 overflow-x-auto no-scrollbar px-3 pb-3">
                {([['all', 'Все'], ['workout', 'Тренировки'], ['other', 'Другое']] as const).map(([id, label]) => (
                  <button key={id} onClick={() => setChip(id)} className={`shrink-0 px-3.5 py-1.5 rounded-lg text-[14px] cursor-pointer border-0 ${chip === id ? 'bg-white text-[#0f0f0f]' : 'bg-[#272727] text-white'}`}>{label}</button>
                ))}
              </div>
              {list.length === 0 ? <div className="px-4 py-10 text-[#aaaaaa] text-[15px]">Ничего не найдено</div> : list.map(card)}
            </>
          )}

          {tab === 'shorts' && (
            <div className="grid grid-cols-2 gap-3 px-3 pb-24">
              {VIDEOS.filter((v) => v.short || v.workout).map((v) => (
                <button key={v.id} onClick={() => open(v)} className="text-left bg-transparent border-0 p-0 cursor-pointer">
                  <div className="relative overflow-hidden rounded-xl aspect-[9/14]" style={{ background: v.poster }}>
                    {v.workout ? <div className="absolute inset-0"><WorkoutVideo playing={false} /></div> : <div className="absolute inset-0 flex items-center justify-center text-6xl">{v.avatarEmoji}</div>}
                    <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent text-[13px] text-white leading-snug line-clamp-2">{v.title}</div>
                  </div>
                  <div className="text-[12px] text-[#aaaaaa] mt-1">{v.views} просмотров</div>
                </button>
              ))}
            </div>
          )}

          {tab === 'subs' && (
            <div className="px-3 pb-24">
              <div className="text-[15px] font-medium mb-3">Каналы</div>
              {channels.map((ch) => {
                const v = VIDEOS.find((x) => x.channel === ch)!;
                return (
                  <div key={ch} className="flex items-center gap-3 py-3 border-b border-white/10">
                    <span className="w-11 h-11 rounded-full bg-[#272727] flex items-center justify-center text-xl">{v.avatarEmoji}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-[15px] truncate">{ch}</div>
                      <div className="text-[12px] text-[#aaaaaa]">{VIDEOS.filter((x) => x.channel === ch).length} видео</div>
                    </div>
                    <button onClick={() => { setSubs((s) => ({ ...s, [ch]: !s[ch] })); }} className={`px-3.5 py-1.5 rounded-full text-[13px] cursor-pointer border-0 ${subs[ch] ? 'bg-[#272727] text-white' : 'bg-white text-[#0f0f0f]'}`}>
                      {subs[ch] ? 'Вы подписаны' : 'Подписаться'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'history' && (
            <div className="pb-24">
              <div className="px-3 text-[15px] font-medium mb-3">История просмотра</div>
              {history.length === 0 ? <div className="px-4 py-10 text-[#aaaaaa] text-[15px]">Вы ещё ничего не смотрели</div> : history.map((id) => card(VIDEOS.find((v) => v.id === id)!))}
            </div>
          )}
        </div>
      )}

      {/* Нижняя навигация */}
      {!selected && (
        <div className="grid grid-cols-4 bg-[#0f0f0f] border-t border-white/10 shrink-0 pb-1">
          {([
            ['home', 'Главная', Home],
            ['shorts', 'Shorts', Zap],
            ['subs', 'Подписки', Users],
            ['history', 'История', HistoryIcon],
          ] as const).map(([id, label, I]) => (
            <button key={id} onClick={() => setTab(id)} className={`py-2 flex flex-col items-center gap-1 bg-transparent border-0 cursor-pointer text-[11px] ${tab === id ? 'text-white' : 'text-[#aaaaaa]'}`}>
              <I className="w-5 h-5" />
              {label}
            </button>
          ))}
        </div>
      )}

      {/* Яндекс.Картинки */}
      {imgModal && (
        <div className="fixed inset-0 bg-black/75 z-[60] flex items-center justify-center p-4" onClick={() => setImgModal(null)}>
          <div className="bg-[#212121] rounded-xl p-5 max-w-sm w-full text-center space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="text-[14px] text-[#ffd84a]">{imgModal}</div>
            <div className="w-32 h-32 mx-auto bg-[#0f0f0f] rounded-lg flex items-center justify-center text-5xl">🖼️</div>
            <p className="text-[12px] text-[#aaaaaa]">Открылись Яндекс.Картинки для аватара канала</p>
            <button onClick={() => setImgModal(null)} className="w-full py-2.5 bg-white text-[#0f0f0f] rounded-full text-[14px] font-medium border-0 cursor-pointer">Закрыть</button>
          </div>
        </div>
      )}
    </div>
  );
};
