import React, { useState, useRef } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { soundManager, triggerHaptic } from '../../utils/soundEffects';
import { Power, Volume2, VolumeX, ChevronUp, ChevronDown, ChevronLeft, ChevronRight, Home, ArrowLeft, Menu, Plus, Minus } from 'lucide-react';

interface ToolProps {
  onClose: () => void;
}

const DEVICES = ['Телевизор', 'Микроволновка', 'Кондиционер', 'Человек'];

export const SmartRemoteTool: React.FC<ToolProps> = ({ onClose }) => {
  const [device, setDevice] = useState(0);
  const [signal, setSignal] = useState('Готов к передаче');
  const [drawer, setDrawer] = useState(false);
  const startX = useRef<number | null>(null);

  const press = (label: string) => {
    triggerHaptic('tap');
    soundManager.playBeep(900, 0.04);
    setSignal(`${DEVICES[device]}: сигнал «${label}» принят`);
  };

  const btn =
    'h-11 border border-white/25 bg-white/[0.06] text-white text-[15px] flex items-center justify-center cursor-pointer active:bg-[#8f9bff] active:text-[#0b0d13] select-none';

  return (
    <ToolWrapper title="Умный пульт" onClose={onClose}>
      <div className="relative flex-1 max-w-md mx-auto w-full select-none">
        {/* Корпус пульта */}
        <div className="rounded-2xl border border-white/25 p-4 space-y-4 bg-[#151826] mr-5">
          {/* Дисплей сигнала */}
          <div className="rounded-2xl border border-white/25 px-3 py-2 min-h-[48px] flex items-center text-[12px] uppercase tracking-[0.02em]">{signal}</div>

          {/* Выбор устройства */}
          <div className="rounded-2xl grid grid-cols-4 border border-white/25">
            {DEVICES.map((d, i) => (
              <button
                key={d}
                onClick={() => {
                  setDevice(i);
                  setSignal(`Выбрано: ${d}`);
                }}
                className={`rounded-2xl py-2 text-[12px] leading-tight cursor-pointer border-0 ${device === i ? 'bg-[#8f9bff] text-[#0b0d13]' : 'bg-white/[0.06] text-white'}`}
              >
                {d}
              </button>
            ))}
          </div>

          {/* Питание, источник, меню */}
          <div className="grid grid-cols-3 gap-2">
            <button className={`rounded-2xl ${btn} border-2`} onClick={() => press('Питание')} aria-label="Питание"><Power className="w-5 h-5" /></button>
            <button className={btn} onClick={() => press('Источник')}>Источник</button>
            <button className={btn} onClick={() => press('Без звука')} aria-label="Без звука"><VolumeX className="w-5 h-5" /></button>
          </div>

          {/* Цифры */}
          <div className="grid grid-cols-3 gap-2">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((n) => (
              <button key={n} className={btn} onClick={() => press(n)}>{n}</button>
            ))}
            <button className={btn} onClick={() => press('Список')}>Список</button>
            <button className={btn} onClick={() => press('0')}>0</button>
            <button className={btn} onClick={() => press('Назад')} aria-label="Предыдущий"><ArrowLeft className="w-5 h-5" /></button>
          </div>

          {/* Громкость / навигация / каналы */}
          <div className="grid grid-cols-[56px_1fr_56px] gap-3 items-center">
            <div className="grid gap-2">
              <button className={btn} onClick={() => press('Громкость +')}><Plus className="w-4 h-4" /></button>
              <div className="text-[12px] text-center text-gray-400 flex items-center justify-center"><Volume2 className="w-4 h-4" /></div>
              <button className={btn} onClick={() => press('Громкость −')}><Minus className="w-4 h-4" /></button>
            </div>

            <div className="grid grid-cols-3 gap-1">
              <span />
              <button className={btn} onClick={() => press('Вверх')}><ChevronUp className="w-5 h-5" /></button>
              <span />
              <button className={btn} onClick={() => press('Влево')}><ChevronLeft className="w-5 h-5" /></button>
              <button className={`rounded-2xl ${btn} border-2`} onClick={() => press('OK')}>OK</button>
              <button className={btn} onClick={() => press('Вправо')}><ChevronRight className="w-5 h-5" /></button>
              <span />
              <button className={btn} onClick={() => press('Вниз')}><ChevronDown className="w-5 h-5" /></button>
              <span />
            </div>

            <div className="grid gap-2">
              <button className={btn} onClick={() => press('Канал +')}><ChevronUp className="w-4 h-4" /></button>
              <div className="text-[12px] text-center text-gray-400">КАН</div>
              <button className={btn} onClick={() => press('Канал −')}><ChevronDown className="w-4 h-4" /></button>
            </div>
          </div>

          {/* Нижний ряд */}
          <div className="grid grid-cols-3 gap-2">
            <button className={btn} onClick={() => press('Домой')}><Home className="w-5 h-5" /></button>
            <button className={btn} onClick={() => press('Меню')}><Menu className="w-5 h-5" /></button>
            <button className={btn} onClick={() => press('Выход')}>Выход</button>
          </div>

          {/* Цветные клавиши (подписаны, цвета не нужны) */}
          <div className="grid grid-cols-4 gap-2">
            {['A', 'B', 'C', 'D'].map((c) => (
              <button key={c} className={`${btn} h-8 text-[12px]`} onClick={() => press(`Функция ${c}`)}>{c}</button>
            ))}
          </div>
        </div>

        {/* Сдвигаемая вкладка с инструкцией */}
        <div
          className="fixed top-24 bottom-24 right-0 z-30 flex"
          style={{ transform: drawer ? 'translateX(0)' : 'translateX(calc(100% - 28px))', transition: 'transform 0.3s ease' }}
        >
          <button
            onClick={() => setDrawer(!drawer)}
            onPointerDown={(e) => (startX.current = e.clientX)}
            onPointerUp={(e) => {
              if (startX.current !== null) {
                const dx = e.clientX - startX.current;
                if (dx > 30) setDrawer(false);
                else if (dx < -30) setDrawer(true);
              }
              startX.current = null;
            }}
            className="rounded-2xl w-7 shrink-0 border border-white/25 border-r-0 bg-[#8f9bff] text-[#0b0d13] cursor-pointer text-[12px] uppercase tracking-[0.02em]"
            style={{ writingMode: 'vertical-rl' }}
            aria-label="Инструкция"
          >
            Инструкция
          </button>
          <div className="rounded-2xl w-[270px] bg-[#151826] border border-white/25 p-4 overflow-y-auto">
            <div className="text-[12px] uppercase tracking-[0.02em] font-medium">Инструкция:</div>
            <h3 className="text-[20px] mt-2 leading-tight">Умный пульт</h3>
            <p className="text-[15px] mt-3 leading-snug">
              Пульт полностью исправен и подходит ко всем типам устройств: телевизору, микроволновой печи, кондиционеру и человеку.
            </p>
            <ol className="text-[15px] mt-3 space-y-2 list-decimal pl-5">
              <li>Выберите устройство в верхней строке.</li>
              <li>Направьте пульт на устройство.</li>
              <li>Нажмите нужную кнопку и дождитесь подтверждения.</li>
            </ol>
            <p className="text-[12px] text-gray-400 mt-4">Дальность действия: до 8 метров. Батарейки не требуются.</p>
          </div>
        </div>
      </div>
    </ToolWrapper>
  );
};
