import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Plus, Minus, RotateCcw, Delete, X } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

/* ====================== Разбор выражений ====================== */

type Fn = (x: number) => number;

interface Tok {
  t: 'num' | 'id' | 'op' | 'lp' | 'rp';
  v: string;
}

const FUNCS: Record<string, (a: number) => number> = {
  sin: Math.sin, cos: Math.cos, tan: Math.tan, tg: Math.tan,
  cot: (a) => 1 / Math.tan(a), ctg: (a) => 1 / Math.tan(a),
  asin: Math.asin, acos: Math.acos, atan: Math.atan, arctg: Math.atan,
  sqrt: Math.sqrt, abs: Math.abs, ln: Math.log, log: Math.log10, lg: Math.log10,
  exp: Math.exp, floor: Math.floor, ceil: Math.ceil, sign: Math.sign,
};

const tokenize = (src: string): Tok[] => {
  const s = src.toLowerCase().replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/π/g, 'pi').replace(/√/g, 'sqrt').replace(/,/g, '.').replace(/\s+/g, '');
  const out: Tok[] = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (/[0-9.]/.test(c)) {
      let j = i;
      while (j < s.length && /[0-9.]/.test(s[j])) j++;
      out.push({ t: 'num', v: s.slice(i, j) });
      i = j;
    } else if (/[a-z]/.test(c)) {
      let j = i;
      while (j < s.length && /[a-z]/.test(s[j])) j++;
      let word = s.slice(i, j);
      // слитные записи вроде «2xsinx»: разбираем жадно по известным именам
      while (word.length) {
        const known = Object.keys(FUNCS).concat(['pi', 'x', 'e']).sort((a, b) => b.length - a.length).find((k) => word.startsWith(k));
        if (!known) throw new Error(`Неизвестное имя «${word}»`);
        out.push({ t: 'id', v: known });
        word = word.slice(known.length);
      }
      i = j;
    } else if (c === '(') { out.push({ t: 'lp', v: c }); i++; }
    else if (c === ')') { out.push({ t: 'rp', v: c }); i++; }
    else if ('+-*/^'.includes(c)) { out.push({ t: 'op', v: c }); i++; }
    else throw new Error(`Недопустимый символ «${c}»`);
  }
  // неявное умножение
  const res: Tok[] = [];
  for (let k = 0; k < out.length; k++) {
    const cur = out[k];
    const prev = res[res.length - 1];
    if (prev) {
      const prevVal = prev.t === 'num' || prev.t === 'rp' || (prev.t === 'id' && !FUNCS[prev.v]);
      const curStart = cur.t === 'lp' || cur.t === 'id' || (cur.t === 'num' && prev.t !== 'num');
      if (prevVal && curStart) res.push({ t: 'op', v: '*' });
    }
    res.push(cur);
  }
  return res;
};

const compile = (src: string): { fn: Fn | null; error: string } => {
  if (!src.trim()) return { fn: null, error: 'Введите функцию' };
  try {
    const toks = tokenize(src);
    let p = 0;
    const peek = () => toks[p];
    const eat = () => toks[p++];

    const expr = (): Fn => {
      let left = term();
      while (peek() && peek().t === 'op' && (peek().v === '+' || peek().v === '-')) {
        const op = eat().v;
        const l = left;
        const r = term();
        left = op === '+' ? (x) => l(x) + r(x) : (x) => l(x) - r(x);
      }
      return left;
    };
    const term = (): Fn => {
      let left = unary();
      while (peek() && peek().t === 'op' && (peek().v === '*' || peek().v === '/')) {
        const op = eat().v;
        const l = left;
        const r = unary();
        left = op === '*' ? (x) => l(x) * r(x) : (x) => l(x) / r(x);
      }
      return left;
    };
    const unary = (): Fn => {
      if (peek() && peek().t === 'op' && (peek().v === '-' || peek().v === '+')) {
        const op = eat().v;
        const u = unary();
        return op === '-' ? (x) => -u(x) : u;
      }
      return power();
    };
    const power = (): Fn => {
      const base = atom();
      if (peek() && peek().t === 'op' && peek().v === '^') {
        eat();
        const ex = unary();
        return (x) => Math.pow(base(x), ex(x));
      }
      return base;
    };
    const atom = (): Fn => {
      const tk = eat();
      if (!tk) throw new Error('Неожиданный конец выражения');
      if (tk.t === 'num') {
        const n = parseFloat(tk.v);
        if (Number.isNaN(n)) throw new Error('Неверное число');
        return () => n;
      }
      if (tk.t === 'lp') {
        const e = expr();
        if (!peek() || peek().t !== 'rp') throw new Error('Не хватает закрывающей скобки');
        eat();
        return e;
      }
      if (tk.t === 'id') {
        if (tk.v === 'x') return (x) => x;
        if (tk.v === 'pi') return () => Math.PI;
        if (tk.v === 'e') return () => Math.E;
        const f = FUNCS[tk.v];
        if (!f) throw new Error(`Неизвестная функция «${tk.v}»`);
        let arg: Fn;
        if (peek() && peek().t === 'lp') {
          eat();
          arg = expr();
          if (!peek() || peek().t !== 'rp') throw new Error('Не хватает закрывающей скобки');
          eat();
        } else {
          arg = power();
        }
        return (x) => f(arg(x));
      }
      throw new Error(`Неожиданный символ «${tk.v}»`);
    };

    const fn = expr();
    if (p < toks.length) throw new Error('Лишние символы в выражении');
    return { fn, error: '' };
  } catch (e) {
    return { fn: null, error: (e as Error).message };
  }
};

/* ====================== Анализ функции ====================== */

const fmt = (n: number): string => {
  if (!Number.isFinite(n)) return n > 0 ? '+∞' : n < 0 ? '−∞' : 'не определено';
  if (Math.abs(n) < 1e-9) return '0';
  if (Math.abs(n) >= 1e7 || Math.abs(n) < 1e-4) return n.toExponential(3).replace('.', ',');
  return String(Number(n.toFixed(4))).replace('.', ',').replace('-', '−');
};

const fmtPi = (t: number): string => {
  const r = t / Math.PI;
  for (let q = 1; q <= 6; q++) {
    const p = r * q;
    if (Math.abs(p - Math.round(p)) < 1e-9 && Math.round(p) !== 0) {
      const pp = Math.round(p);
      return `${pp === 1 ? '' : pp}π${q === 1 ? '' : '/' + q}`;
    }
  }
  return fmt(t);
};

interface Analysis {
  domain: string;
  range: string;
  zeros: number[];
  yIntercept: string;
  parity: string;
  period: string;
  extrema: Array<{ x: number; y: number; kind: 'max' | 'min' }>;
  monotony: Array<{ a: number; b: number; up: boolean }>;
  asymptotesV: number[];
  limits: { plus: string; minus: string };
  inflections: Array<{ x: number; y: number }>;
  asymptoteH: string[];
}

const analyze = (f: Fn): Analysis => {
  const safe = (x: number) => {
    const y = f(x);
    return Number.isFinite(y) ? y : NaN;
  };
  const isDef = (x: number) => !Number.isNaN(safe(x));
  const X0 = -60, X1 = 60, N = 12000;
  const h = (X1 - X0) / N;
  const xs: number[] = new Array(N + 1);
  const ys: number[] = new Array(N + 1);
  for (let i = 0; i <= N; i++) {
    xs[i] = X0 + i * h;
    ys[i] = safe(xs[i]);
  }
  const R4 = (v: number) => Math.round(v * 10000) / 10000;
  const boundary = (u: number, d: number) => {
    for (let k = 0; k < 60; k++) {
      const m = (u + d) / 2;
      if (isDef(m)) d = m; else u = m;
    }
    return (u + d) / 2;
  };

  /* ----- Область определения ----- */
  interface Run { i0: number; i1: number; lo: number | null; hi: number | null }
  const runs: Run[] = [];
  let rs = -1;
  for (let i = 0; i <= N + 1; i++) {
    const bad = i <= N && Number.isNaN(ys[i]);
    if (bad && rs < 0) rs = i;
    if (!bad && rs >= 0) {
      const i1 = i - 1;
      runs.push({
        i0: rs,
        i1,
        lo: rs > 0 ? boundary(xs[rs], xs[rs - 1]) : null,
        hi: i1 < N ? boundary(xs[i1], xs[i1 + 1]) : null,
      });
      rs = -1;
    }
  }
  let domain = 'x ∈ (−∞; +∞)';
  let leftEdge = X0, rightEdge = X1;
  const whole = runs.length === 1 && runs[0].i0 === 0 && runs[0].i1 === N;
  if (whole) domain = 'Функция нигде не определена';
  else if (runs.length) {
    const lr = runs.find((r) => r.i0 === 0);
    const rr = runs.find((r) => r.i1 === N);
    const inner = runs.filter((r) => r !== lr && r !== rr);
    let start = '(−∞', end = '+∞)';
    if (lr && lr.hi !== null) {
      const v = R4(lr.hi);
      start = (isDef(v) ? '[' : '(') + fmt(v);
      leftEdge = lr.hi;
    }
    if (rr && rr.lo !== null) {
      const v = R4(rr.lo);
      end = fmt(v) + (isDef(v) ? ']' : ')');
      rightEdge = rr.lo;
    }
    domain = `x ∈ ${start}; ${end}`;
    if (inner.length) {
      domain += ', кроме: ' + inner.map((r) => (r.i1 - r.i0 < 3 ? `x = ${fmt(R4((r.lo! + r.hi!) / 2))}` : `x ∈ (${fmt(R4(r.lo!))}; ${fmt(R4(r.hi!))})`)).join('; ');
    }
  }

  /* ----- Пределы и асимптоты на бесконечности ----- */
  const limAt = (sgn: number) => {
    const v = [1e3, 1e4, 1e5, 1e6, 1e7].map((m) => f(sgn * m));
    if (v.some((q) => Number.isNaN(q))) return { text: 'не определено', kind: 'none' as const, L: NaN, h: '' };
    const last = v[4];
    if (last === Infinity || last === -Infinity) return { text: last > 0 ? '+∞' : '−∞', kind: (last > 0 ? 'inf+' : 'inf-') as 'inf+' | 'inf-', L: last, h: '' };
    const d1 = Math.abs(v[3] - v[2]), d2 = Math.abs(v[4] - v[3]);
    if (Math.abs(v[4]) < 1e-5 && Math.abs(v[3]) < 1e-4 && Math.abs(v[2]) < 1e-3) {
      return { text: '0', kind: 'fin' as const, L: 0, h: 'y = 0' };
    }
    if (d2 < 1e-3 && d2 <= 0.25 * d1 + 1e-12) {
      const L = Math.abs(v[4]) < 1e-6 ? 0 : v[4];
      return { text: fmt(L), kind: 'fin' as const, L, h: `y = ${fmt(L)}` };
    }
    const grow = Math.abs(v[1]) > Math.abs(v[0]) && Math.abs(v[2]) > Math.abs(v[1]) && Math.abs(v[3]) > Math.abs(v[2]) && Math.abs(v[4]) > Math.abs(v[3]) && Math.abs(v[4]) > 10 && Math.sign(v[4]) === Math.sign(v[0]);
    if (grow) {
      const x1 = sgn * 1e5, x2 = sgn * 1e7;
      const ka = (f(2 * x1) - f(x1)) / x1, kb = (f(2 * x2) - f(x2)) / x2;
      let h2 = '';
      if (Math.abs(kb) > 1e-6 && Math.abs(ka - kb) < 1e-4 * (1 + Math.abs(kb))) {
        const b1 = f(x1) - kb * x1, b2 = f(x2) - kb * x2;
        if (Math.abs(b1 - b2) < 1e-2 * (1 + Math.abs(b2))) {
          const kk = Math.round(kb * 1e6) / 1e6;
          const bb = Math.round(b2 * 1e4) / 1e4;
          const kt = kk === 1 ? 'x' : kk === -1 ? '−x' : `${fmt(kk)}x`;
          h2 = bb === 0 ? `y = ${kt}` : `y = ${kt} ${bb > 0 ? '+' : '−'} ${fmt(Math.abs(bb))}`;
        }
      }
      return { text: last > 0 ? '+∞' : '−∞', kind: (last > 0 ? 'inf+' : 'inf-') as 'inf+' | 'inf-', L: last, h: h2 };
    }
    return { text: 'предела нет', kind: 'none' as const, L: NaN, h: '' };
  };
  const lp = limAt(1), lm = limAt(-1);

  /* ----- Вертикальные асимптоты ----- */
  const asymV: number[] = [];
  const addAsym = (x: number) => {
    const key = Math.round(x * 1000) / 1000;
    if (!asymV.some((v) => Math.abs(v - key) < 0.02)) asymV.push(key);
  };
  const upDownAt = (x: number) => {
    let up = false, down = false;
    [1e-6, 1e-7, -1e-6, -1e-7].forEach((e) => {
      const y = f(x + e);
      if (y > 1e5 || y === Infinity) up = true;
      if (y < -1e5 || y === -Infinity) down = true;
    });
    return { up, down };
  };
  const growsAt = (x: number) => {
    const g = (e: number) => {
      const a = Math.abs(f(x + e * 1e3)), b = Math.abs(f(x + e));
      return (b > 4 * a && b > 100) || (b === Infinity && a > 10);
    };
    return g(1e-6) || g(-1e-6);
  };
  let rangeUp = lp.kind === 'inf+' || lm.kind === 'inf+';
  let rangeDown = lp.kind === 'inf-' || lm.kind === 'inf-';
  const sideGrows = (x: number, dir: number) => {
    const v = [1e-3, 1e-6, 1e-9, 1e-12].map((e) => Math.abs(f(x + dir * e)));
    if (v.some((q) => Number.isNaN(q))) return false;
    return v[1] > v[0] && v[2] > v[1] && v[3] > v[2] && v[3] > 20;
  };
  const sideSign = (x: number, dir: number) => f(x + dir * 1e-9);
  runs.forEach((r) => {
    ([[r.lo, -1], [r.hi, 1]] as Array<[number | null, number]>).forEach(([x, dir]) => {
      if (x === null) return;
      if (sideGrows(x, dir)) {
        addAsym(x);
        const sv = sideSign(x, dir);
        if (sv > 0) rangeUp = true;
        else if (sv < 0) rangeDown = true;
      }
    });
  });
  // разрывы второго рода без неопределённости (например, tan x)
  const absY = (i: number) => (Number.isNaN(ys[i]) ? -1 : Math.abs(ys[i]));
  for (let i = 2; i < N - 2; i++) {
    const v = absY(i);
    if (v < 30 || v < absY(i - 1) || v < absY(i + 1)) continue;
    let lo = xs[i - 1], hi = xs[i + 2];
    const gr = (Math.sqrt(5) - 1) / 2;
    let c = hi - gr * (hi - lo), dd = lo + gr * (hi - lo);
    for (let k = 0; k < 70; k++) {
      const fc = Math.abs(f(c)), fd = Math.abs(f(dd));
      if ((Number.isNaN(fc) ? -1 : fc) < (Number.isNaN(fd) ? -1 : fd)) lo = c; else hi = dd;
      c = hi - gr * (hi - lo);
      dd = lo + gr * (hi - lo);
    }
    const p = (lo + hi) / 2;
    if (growsAt(p)) {
      addAsym(p);
      const ud = upDownAt(p);
      rangeUp = rangeUp || ud.up;
      rangeDown = rangeDown || ud.down;
    }
    if (asymV.length > 24) break;
  }
  asymV.sort((p, q) => p - q);

  /* ----- Область значений ----- */
  let minY = Infinity, maxY = -Infinity, minI = -1, maxI = -1;
  for (let i = 0; i <= N; i++) {
    if (Number.isNaN(ys[i])) continue;
    if (ys[i] < minY) { minY = ys[i]; minI = i; }
    if (ys[i] > maxY) { maxY = ys[i]; maxI = i; }
  }
  let range = '—';
  if (isFinite(minY)) {
    if (maxY >= 1e5) rangeUp = true;
    if (minY <= -1e5) rangeDown = true;
    const edge = (i: number) => i <= 1 || i >= N - 1;
    let loTxt = fmt(minY), hiTxt = fmt(maxY);
    let loBr = edge(minI) ? '(' : '[', hiBr = edge(maxI) ? ')' : ']';
    // функция приближается к горизонтальной асимптоте, но не достигает её
    [lp, lm].forEach((l) => {
      if (l.kind !== 'fin') return;
      if (!rangeDown && edge(minI) && Math.abs(minY - l.L) < 1e-2 * (1 + Math.abs(l.L))) { loTxt = fmt(l.L); loBr = '('; }
      if (!rangeUp && edge(maxI) && Math.abs(maxY - l.L) < 1e-2 * (1 + Math.abs(l.L))) { hiTxt = fmt(l.L); hiBr = ')'; }
    });
    if (rangeDown && rangeUp) {
      range = 'y ∈ (−∞; +∞)';
      const fin = [lp, lm].find((l) => l.kind === 'fin');
      if (fin) {
        let cross = false;
        for (let i = 0; i < N && !cross; i++) {
          if (Number.isNaN(ys[i]) || Number.isNaN(ys[i + 1])) continue;
          if ((ys[i] - fin.L) * (ys[i + 1] - fin.L) < 0) cross = true;
          if (Math.abs(ys[i] - fin.L) < 1e-9 && Math.abs(fin.L) > 0) cross = true;
        }
        if (!cross) range = `y ∈ (−∞; ${fmt(fin.L)}) ∪ (${fmt(fin.L)}; +∞)`;
      }
    } else if (rangeUp) range = `y ∈ ${loBr}${loTxt}; +∞)`;
    else if (rangeDown) range = `y ∈ (−∞; ${hiTxt}${hiBr}`;
    else range = `y ∈ ${loBr}${loTxt}; ${hiTxt}${hiBr}`;
  }

  /* ----- Нули ----- */
  const zeros: number[] = [];
  const addZero = (z: number) => {
    if (!zeros.some((q) => Math.abs(q - z) < 1e-4)) zeros.push(z);
  };
  for (let i = 1; i < N; i++) {
    const a = ys[i], b = ys[i + 1];
    if (Number.isNaN(a)) continue;
    if (Math.abs(a) < 1e-9 && !Number.isNaN(ys[i - 1]) && !Number.isNaN(b) && Math.abs(a) <= Math.abs(ys[i - 1]) && Math.abs(a) <= Math.abs(b) && Math.abs(ys[i - 1]) > 1e-9 + Math.abs(a) * 0 && (Math.abs(ys[i - 1]) > 1e-12 || Math.abs(b) > 1e-12)) {
      addZero(Math.abs(xs[i]) < 1e-9 ? 0 : xs[i]);
      continue;
    }
    if (Number.isNaN(b)) continue;
    if (a * b < 0 && Math.abs(a) < 1e3 && Math.abs(b) < 1e3) {
      let lo = xs[i], hi = xs[i + 1], fl = a;
      for (let k = 0; k < 55; k++) {
        const mid = (lo + hi) / 2;
        const fm = safe(mid);
        if (Number.isNaN(fm)) break;
        if (fl * fm <= 0) hi = mid; else { lo = mid; fl = fm; }
      }
      const z = (lo + hi) / 2;
      // отсекаем смену знака на разрыве (например, у tan x)
      const zv = safe(z);
      if (!Number.isNaN(zv) && Math.abs(zv) < 1e-6 * (1 + Math.abs(a) + Math.abs(b))) addZero(Math.abs(z) < 1e-9 ? 0 : z);
    }
    if (zeros.length > 60) break;
  }
  zeros.sort((p, q) => p - q);

  const y0 = safe(0);
  const yIntercept = Number.isNaN(y0) ? 'нет (в точке x = 0 функция не определена)' : `(0; ${fmt(y0)})`;

  /* ----- Чётность ----- */
  let even = true, odd = true, checked = 0, asym = false;
  for (let x = 0.13; x < 25; x += 0.77) {
    const a = safe(x), b = safe(-x);
    if (Number.isNaN(a) && Number.isNaN(b)) continue;
    if (Number.isNaN(a) !== Number.isNaN(b)) { asym = true; break; }
    checked++;
    if (Math.abs(a - b) > 1e-7 * (1 + Math.abs(a))) even = false;
    if (Math.abs(a + b) > 1e-7 * (1 + Math.abs(a))) odd = false;
  }
  const parity = asym || checked === 0 ? 'общего вида (область определения несимметрична)' : even && odd ? 'чётная и нечётная (нулевая функция)' : even ? 'чётная (график симметричен относительно оси Oy)' : odd ? 'нечётная (график симметричен относительно начала координат)' : 'общего вида (ни чётная, ни нечётная)';

  /* ----- Периодичность ----- */
  let period = 'непериодическая';
  if (isFinite(minY) && Math.abs(maxY - minY) < 1e-9) period = 'постоянная (период — любое число)';
  else {
    const cands = [Math.PI / 4, Math.PI / 3, Math.PI / 2, (2 * Math.PI) / 3, Math.PI, 2 * Math.PI, 4 * Math.PI, 1, 2, 3, 4, 5, 6, 8, 10, 12, 20, 24, 25, 50].sort((p, q) => p - q);
    for (const T of cands) {
      let ok = true, cnt = 0;
      for (let x = -9.37; x < 9.5; x += 0.31) {
        const a = safe(x), b = safe(x + T);
        if (Number.isNaN(a) && Number.isNaN(b)) continue;
        if (Number.isNaN(a) !== Number.isNaN(b)) { ok = false; break; }
        cnt++;
        if (Math.abs(a - b) > 1e-6 * (1 + Math.abs(a))) { ok = false; break; }
      }
      if (ok && cnt > 15) { period = `периодическая, T = ${fmtPi(T)}`; break; }
    }
  }

  /* ----- Экстремумы ----- */
  const d = (i: number) => (ys[i + 1] - ys[i - 1]) / (2 * h);
  const extrema: Analysis['extrema'] = [];
  const golden = (lo: number, hi: number, sign: number) => {
    const gr = (Math.sqrt(5) - 1) / 2;
    let c = hi - gr * (hi - lo), dd = lo + gr * (hi - lo);
    for (let k = 0; k < 70; k++) {
      if (sign * safe(c) > sign * safe(dd)) hi = dd; else lo = c;
      c = hi - gr * (hi - lo);
      dd = lo + gr * (hi - lo);
    }
    return (lo + hi) / 2;
  };
  for (let i = 2; i < N - 1; i++) {
    if ([ys[i - 2], ys[i - 1], ys[i], ys[i + 1]].some(Number.isNaN)) continue;
    if (Math.abs(ys[i + 1] - ys[i - 1]) > 50) continue;
    const dA = d(i - 1), dB = d(i);
    const kind = dA > 1e-9 && dB <= 1e-9 ? 'max' : dA < -1e-9 && dB >= -1e-9 ? 'min' : null;
    if (!kind) continue;
    const x = golden(xs[i - 2], xs[i + 1], kind === 'max' ? 1 : -1);
    const y = safe(x);
    if (!Number.isNaN(y) && !extrema.some((e) => Math.abs(e.x - x) < 1e-3)) extrema.push({ x: Math.abs(x) < 1e-7 ? 0 : x, y, kind });
    if (extrema.length > 40) break;
  }
  extrema.sort((p, q) => p.x - q.x);

  /* ----- Промежутки монотонности ----- */
  const inner = runs.filter((r) => r.lo !== null && r.hi !== null);
  const brk = [...extrema.map((e) => e.x), ...inner.flatMap((r) => [r.lo as number, r.hi as number]), ...asymV].sort((p, q) => p - q);
  const edges = [leftEdge, ...brk, rightEdge];
  const monotony: Analysis['monotony'] = [];
  for (let k = 0; k < edges.length - 1 && monotony.length < 18; k++) {
    const a = edges[k], b = edges[k + 1];
    if (b - a < 1e-3) continue;
    const m = (a + b) / 2;
    const dl = Math.min(1e-3, (b - a) / 10);
    const y1 = safe(m - dl), y2 = safe(m + dl);
    if (Number.isNaN(y1) || Number.isNaN(y2) || y1 === y2) continue;
    monotony.push({ a, b, up: y2 > y1 });
  }

  /* ----- Точки перегиба ----- */
  const e2 = 0.02;
  const ddx = (x: number) => (safe(x + e2) - 2 * safe(x) + safe(x - e2)) / (e2 * e2);
  const inflections: Analysis['inflections'] = [];
  let px = NaN, pv = NaN;
  for (let x = X0 + 0.5; x < X1 - 0.5; x += 0.1) {
    const v = ddx(x);
    if (Number.isNaN(v) || Math.abs(v) > 1e4) { pv = NaN; continue; }
    if (!Number.isNaN(pv) && Math.abs(pv) > 1e-3 && Math.abs(v) > 1e-3 && pv * v < 0) {
      let lo = px, hi = x, fl = pv;
      for (let k = 0; k < 40; k++) {
        const mid = (lo + hi) / 2;
        const fm = ddx(mid);
        if (Number.isNaN(fm)) break;
        if (fl * fm <= 0) hi = mid; else { lo = mid; fl = fm; }
      }
      const xi = (lo + hi) / 2;
      const yi = safe(xi);
      if (!Number.isNaN(yi) && !inflections.some((q) => Math.abs(q.x - xi) < 0.05)) inflections.push({ x: Math.abs(xi) < 1e-6 ? 0 : xi, y: yi });
    }
    px = x;
    pv = v;
    if (inflections.length >= 12) break;
  }

  const asymptoteH = Array.from(new Set([lp.h && `при x → +∞: ${lp.h}`, lm.h && `при x → −∞: ${lm.h}`].filter(Boolean) as string[]));

  return {
    domain, range, zeros, yIntercept, parity, period, extrema, monotony, asymptotesV: asymV,
    limits: { plus: lp.text, minus: lm.text }, inflections, asymptoteH,
  };
};

/* ====================== Интерфейс ====================== */

const COLORS = ['#8f9bff', '#34d399', '#fbbf24'];
const W = 640, H = 460;

const niceStep = (raw: number) => {
  const p = Math.pow(10, Math.floor(Math.log10(raw)));
  const f = raw / p;
  return (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10) * p;
};

const KEYS: string[][] = [
  ['sin(', 'cos(', 'tan(', 'ctg('],
  ['ln(', 'log(', '√(', 'abs('],
  ['(', ')', '^', 'π'],
  ['7', '8', '9', '÷'],
  ['4', '5', '6', '×'],
  ['1', '2', '3', '−'],
  ['0', ',', 'x', '+'],
];

export const FunctionGraphTool: React.FC<ToolProps> = ({ onClose }) => {
  const [funcs, setFuncs] = useState<string[]>(['x^3-3x']);
  const [active, setActive] = useState(0);
  const [view, setView] = useState({ cx: 0, cy: 0, scale: 55 });
  const [tab, setTab] = useState<'calc' | 'analysis'>('calc');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drag = useRef<{ x: number; y: number } | null>(null);

  const compiled = useMemo(() => funcs.map((s) => compile(s)), [funcs]);
  const analysis = useMemo(() => {
    const c = compiled[active];
    return c && c.fn ? analyze(c.fn) : null;
  }, [compiled, active]);

  const setExpr = (s: string) => setFuncs((fs) => fs.map((f, i) => (i === active ? s : f)));
  const press = (k: string) => {
    soundManager.playBeep(900, 0.03);
    setFuncs((fs) => fs.map((f, i) => (i === active ? f + k : f)));
  };

  // отрисовка
  const draw = useCallback(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const { cx, cy, scale } = view;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#0f121a';
    ctx.fillRect(0, 0, W, H);
    const X = (x: number) => W / 2 + (x - cx) * scale;
    const Y = (y: number) => H / 2 - (y - cy) * scale;
    const step = niceStep(70 / scale);

    // сетка
    ctx.lineWidth = 1;
    ctx.font = '11px sans-serif';
    ctx.fillStyle = '#7d84a6';
    const xmin = cx - W / 2 / scale, xmax = cx + W / 2 / scale, ymin = cy - H / 2 / scale, ymax = cy + H / 2 / scale;
    for (let gx = Math.ceil(xmin / step) * step; gx <= xmax; gx += step) {
      ctx.strokeStyle = Math.abs(gx) < step / 2 ? '#aab0d0' : '#23283a';
      ctx.beginPath(); ctx.moveTo(X(gx), 0); ctx.lineTo(X(gx), H); ctx.stroke();
      if (Math.abs(gx) > step / 2) ctx.fillText(fmt(gx), X(gx) + 3, Math.min(H - 4, Math.max(12, Y(0) + 13)));
    }
    for (let gy = Math.ceil(ymin / step) * step; gy <= ymax; gy += step) {
      ctx.strokeStyle = Math.abs(gy) < step / 2 ? '#aab0d0' : '#23283a';
      ctx.beginPath(); ctx.moveTo(0, Y(gy)); ctx.lineTo(W, Y(gy)); ctx.stroke();
      if (Math.abs(gy) > step / 2) ctx.fillText(fmt(gy), Math.min(W - 40, Math.max(4, X(0) + 4)), Y(gy) - 3);
    }

    // функции
    compiled.forEach((cmp, idx) => {
      if (!cmp.fn) return;
      ctx.strokeStyle = COLORS[idx % COLORS.length];
      ctx.lineWidth = idx === active ? 2.6 : 1.8;
      ctx.beginPath();
      let pen = false, prevPy = 0;
      for (let px = 0; px <= W; px++) {
        const x = cx + (px - W / 2) / scale;
        const y = cmp.fn(x);
        if (!Number.isFinite(y) || Math.abs(y) > 1e7) { pen = false; continue; }
        const py = Y(y);
        if (pen && Math.abs(py - prevPy) > H * 1.2) pen = false;
        if (!pen) { ctx.moveTo(px, py); pen = true; } else ctx.lineTo(px, py);
        prevPy = py;
      }
      ctx.stroke();
    });

    // отметки анализа для активной функции
    if (analysis) {
      ctx.setLineDash([5, 4]);
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1;
      analysis.asymptotesV.forEach((a) => { ctx.beginPath(); ctx.moveTo(X(a), 0); ctx.lineTo(X(a), H); ctx.stroke(); });
      ctx.setLineDash([]);
      ctx.fillStyle = '#ffffff';
      analysis.zeros.forEach((z) => { ctx.beginPath(); ctx.arc(X(z), Y(0), 3.5, 0, Math.PI * 2); ctx.fill(); });
      analysis.extrema.forEach((e) => {
        ctx.fillStyle = e.kind === 'max' ? '#f87171' : '#60a5fa';
        ctx.fillRect(X(e.x) - 4, Y(e.y) - 4, 8, 8);
      });
      analysis.inflections.forEach((p) => {
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath(); ctx.moveTo(X(p.x), Y(p.y) - 5); ctx.lineTo(X(p.x) + 5, Y(p.y) + 4); ctx.lineTo(X(p.x) - 5, Y(p.y) + 4); ctx.closePath(); ctx.fill();
      });
    }
  }, [view, compiled, active, analysis]);

  useEffect(() => { draw(); }, [draw]);

  // перемещение и масштаб
  const onDown = (e: React.PointerEvent) => { drag.current = { x: e.clientX, y: e.clientY }; (e.target as Element).setPointerCapture?.(e.pointerId); };
  const onMove = (e: React.PointerEvent) => {
    if (!drag.current || !canvasRef.current) return;
    const r = canvasRef.current.getBoundingClientRect();
    const k = W / r.width;
    const dx = (e.clientX - drag.current.x) * k, dy = (e.clientY - drag.current.y) * k;
    drag.current = { x: e.clientX, y: e.clientY };
    setView((v) => ({ ...v, cx: v.cx - dx / v.scale, cy: v.cy + dy / v.scale }));
  };
  const onUp = () => { drag.current = null; };
  const zoom = (f: number) => setView((v) => ({ ...v, scale: Math.max(2, Math.min(5000, v.scale * f)) }));

  const cur = compiled[active];
  const btn = 'h-11 rounded-xl bg-white/[0.07] hover:bg-white/[0.14] text-white text-[15px] font-medium cursor-pointer border border-white/10 active:scale-95 transition-all';

  return (
    <ToolWrapper title="Графики функций" onClose={onClose}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col gap-3 select-none">
        {/* График */}
        <div className="relative rounded-2xl overflow-hidden border border-white/10">
          <canvas
            ref={canvasRef}
            width={W}
            height={H}
            className="w-full h-auto block touch-none cursor-grab"
            onPointerDown={onDown}
            onPointerMove={onMove}
            onPointerUp={onUp}
            onPointerCancel={onUp}
            onWheel={(e) => zoom(e.deltaY < 0 ? 1.15 : 1 / 1.15)}
          />
          <div className="absolute right-2 top-2 flex flex-col gap-1.5">
            <button onClick={() => zoom(1.4)} className="w-9 h-9 rounded-lg bg-black/60 text-white border border-white/20 flex items-center justify-center cursor-pointer" aria-label="Приблизить"><Plus className="w-4 h-4" /></button>
            <button onClick={() => zoom(1 / 1.4)} className="w-9 h-9 rounded-lg bg-black/60 text-white border border-white/20 flex items-center justify-center cursor-pointer" aria-label="Отдалить"><Minus className="w-4 h-4" /></button>
            <button onClick={() => setView({ cx: 0, cy: 0, scale: 55 })} className="w-9 h-9 rounded-lg bg-black/60 text-white border border-white/20 flex items-center justify-center cursor-pointer" aria-label="Сбросить"><RotateCcw className="w-4 h-4" /></button>
          </div>
        </div>

        {/* Список функций */}
        <div className="space-y-1.5">
          {funcs.map((f, i) => (
            <div key={i} onClick={() => setActive(i)} className={`flex items-center gap-2 px-3 py-2 rounded-xl border cursor-pointer ${active === i ? 'border-white/40 bg-white/[0.08]' : 'border-white/10 bg-white/[0.03]'}`}>
              <span className="w-3 h-3 rounded-full shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
              <span className="text-[13px] text-gray-400 shrink-0">f<sub>{i + 1}</sub>(x) =</span>
              <input value={f} onChange={(e) => setFuncs((fs) => fs.map((q, k) => (k === i ? e.target.value : q)))} onFocus={() => setActive(i)} placeholder="например, sin(x)/x" className="flex-1 min-w-0 bg-transparent outline-none text-white text-[15px]" />
              {funcs.length > 1 && (
                <button onClick={(e) => { e.stopPropagation(); setFuncs((fs) => fs.filter((_, k) => k !== i)); setActive(0); }} className="bg-transparent border-0 text-gray-400 cursor-pointer p-1" aria-label="Удалить"><X className="w-4 h-4" /></button>
              )}
            </div>
          ))}
          {funcs.length < 3 && (
            <button onClick={() => { setFuncs((fs) => [...fs, 'sin(x)']); setActive(funcs.length); }} className="text-[13px] text-[#8f9bff] bg-transparent border-0 cursor-pointer p-1">+ Добавить функцию</button>
          )}
          <div className="h-5 text-[12px] text-red-300 px-1">{cur && cur.error ? cur.error : ''}</div>
        </div>

        {/* Вкладки */}
        <div className="grid grid-cols-2 gap-1 p-1 rounded-full bg-white/[0.06] border border-white/10">
          {([['calc', 'Калькулятор'], ['analysis', 'Анализ функции']] as const).map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)} className={`py-2.5 rounded-full text-[13px] font-medium cursor-pointer border-0 ${tab === id ? 'bg-[#8f9bff] text-[#0b0d13]' : 'bg-transparent text-gray-300'}`}>{label}</button>
          ))}
        </div>

        {tab === 'calc' && (
          <div className="grid grid-cols-4 gap-2 pb-6">
            {KEYS.flat().map((k) => (
              <button key={k} onClick={() => press(k)} className={btn}>{k.replace('(', '')}</button>
            ))}
            <button onClick={() => setExpr(funcs[active].slice(0, -1))} className={btn} aria-label="Стереть"><Delete className="w-5 h-5 mx-auto" /></button>
            <button onClick={() => setExpr('')} className={btn}>C</button>
            <button onClick={() => press('e')} className={btn}>e</button>
            <button onClick={() => press('/')} className={btn}>/</button>
          </div>
        )}

        {tab === 'analysis' && (
          <div className="pb-8 space-y-2 text-[14px]">
            {!analysis ? (
              <div className="text-gray-400 py-6 text-center">Введите корректную функцию для анализа</div>
            ) : (
              <>
                {[
                  ['Область определения', analysis.domain],
                  ['Область значений (≈)', analysis.range],
                  ['Пересечение с осью Oy', analysis.yIntercept],
                  ['Чётность', analysis.parity],
                  ['Периодичность', analysis.period],
                  ['Предел при x → +∞', analysis.limits.plus],
                  ['Предел при x → −∞', analysis.limits.minus],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                    <div className="text-[11px] uppercase tracking-wide text-gray-400">{k}</div>
                    <div className="text-white mt-0.5 break-words">{v}</div>
                  </div>
                ))}
                <div className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                  <div className="text-[11px] uppercase tracking-wide text-gray-400">Нули функции (○)</div>
                  <div className="text-white mt-0.5 break-words">{analysis.zeros.length ? analysis.zeros.slice(0, 14).map((z) => `x = ${fmt(z)}`).join('; ') + (analysis.zeros.length > 14 ? '; …' : '') : 'нулей нет на [−60; 60]'}</div>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                  <div className="text-[11px] uppercase tracking-wide text-gray-400">Экстремумы (■)</div>
                  <div className="text-white mt-0.5 space-y-0.5">
                    {analysis.extrema.length ? analysis.extrema.slice(0, 12).map((e, i) => (
                      <div key={i}>{e.kind === 'max' ? 'максимум' : 'минимум'}: ({fmt(e.x)}; {fmt(e.y)})</div>
                    )) : 'экстремумов нет'}
                  </div>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                  <div className="text-[11px] uppercase tracking-wide text-gray-400">Промежутки монотонности</div>
                  <div className="text-white mt-0.5 space-y-0.5">
                    {analysis.monotony.length ? analysis.monotony.map((m, i) => (
                      <div key={i}>{m.up ? 'возрастает' : 'убывает'}: {m.a <= -59.9 ? '(−∞' : '(' + fmt(m.a)}; {m.b >= 59.9 ? '+∞)' : fmt(m.b) + ')'}</div>
                    )) : 'не определены'}
                  </div>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                  <div className="text-[11px] uppercase tracking-wide text-gray-400">Асимптоты</div>
                  <div className="text-white mt-0.5 space-y-0.5">
                    {analysis.asymptotesV.map((a, i) => <div key={'v' + i}>вертикальная: x = {fmt(a)}</div>)}
                    {analysis.asymptoteH.map((a, i) => <div key={'h' + i}>{a}</div>)}
                    {!analysis.asymptotesV.length && !analysis.asymptoteH.length && 'асимптот нет'}
                  </div>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                  <div className="text-[11px] uppercase tracking-wide text-gray-400">Точки перегиба (▲)</div>
                  <div className="text-white mt-0.5 space-y-0.5">
                    {analysis.inflections.length ? analysis.inflections.map((p, i) => <div key={i}>({fmt(p.x)}; {fmt(p.y)})</div>) : 'точек перегиба нет'}
                  </div>
                </div>
                <p className="text-[12px] text-gray-500 px-1">Анализ выполнен численно на отрезке [−60; 60]. Значения приближённые.</p>
              </>
            )}
          </div>
        )}
      </div>
    </ToolWrapper>
  );
};
