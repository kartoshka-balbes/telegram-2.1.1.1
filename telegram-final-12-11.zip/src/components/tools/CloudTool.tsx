import React, { useState } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { soundManager, triggerHaptic } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

interface Question {
  kind: string;
  text: string;
  options: string[];
  answer: number;
}

const QUESTIONS: Question[] = [
  { kind: 'Пример', text: '8 + 6 = ?', options: ['12', '13', '14', '16'], answer: 2 },
  { kind: 'Пример', text: '15 − 7 = ?', options: ['6', '8', '9', '7'], answer: 1 },
  { kind: 'Пример', text: '4 × 5 = ?', options: ['25', '18', '24', '20'], answer: 3 },
  { kind: 'Шарада', text: 'Не лает, не кусает, а в дом не пускает.', options: ['Окно', 'Замок', 'Забор', 'Дверь'], answer: 1 },
  { kind: 'Шарада', text: 'Что можно увидеть с закрытыми глазами?', options: ['Сон', 'Тень', 'Свет', 'Цвет'], answer: 0 },
  { kind: 'Ребус', text: '☀️ + 🌻', options: ['Лето', 'Подсолнух', 'Поле', 'Цветок'], answer: 1 },
  { kind: 'Ребус', text: '🐝 + 🏠', options: ['Улей', 'Сад', 'Мёд', 'Пчела'], answer: 0 },
];

const START_LIMIT_KB = 2;
const BIG_LIMIT_TB = 256;

type Stage = 'idle' | 'security' | 'transfer' | 'boom' | 'error';

export const CloudTool: React.FC<ToolProps> = ({ onClose }) => {
  const [passed, setPassed] = useState(false);
  const [step, setStep] = useState(0);
  const [wrong, setWrong] = useState(false);
  const [stage, setStage] = useState<Stage>('idle');
  const [toast, setToast] = useState('');
  const [progress, setProgress] = useState(0);
  const [addedTb, setAddedTb] = useState(0);

  const showToast = (t: string) => {
    setToast(t);
    window.setTimeout(() => setToast(''), 2200);
  };

  const addFile = () => {
    soundManager.playBeep(900, 0.05);
    if (!passed) {
      showToast('Недостаточно памяти');
      return;
    }
    const tb = Math.floor(2 + Math.random() * 18);
    setAddedTb((a) => Math.min(BIG_LIMIT_TB, a + tb));
    showToast(`Файл добавлен: ${tb} ТБ`);
  };

  const answer = (i: number) => {
    triggerHaptic('tap');
    if (i === QUESTIONS[step].answer) {
      setWrong(false);
      if (step + 1 >= QUESTIONS.length) {
        setPassed(true);
        setStage('idle');
        setStep(0);
        showToast(`Проверка пройдена. Объём увеличен до ${BIG_LIMIT_TB} ТБ`);
      } else {
        setStep(step + 1);
      }
    } else {
      setWrong(true);
    }
  };

  const startTransfer = () => {
    setStage('transfer');
    setProgress(0);
    let p = 0;
    const id = window.setInterval(() => {
      p += 1.4 + Math.random() * 2.2;
      if (p >= 100) {
        window.clearInterval(id);
        setProgress(100);
        // места не хватает: полоса загрузки взрывается
        window.setTimeout(() => {
          setStage('boom');
          soundManager.playExplosion();
          triggerHaptic('heavy');
          window.setTimeout(() => setStage('error'), 1500);
        }, 250);
      } else {
        setProgress(p);
      }
    }, 90);
  };

  const limitText = passed ? `${BIG_LIMIT_TB} ТБ` : `${START_LIMIT_KB} КБ`;
  const usedText = passed ? `${addedTb.toLocaleString('ru-RU')} ТБ` : '1,7 КБ';
  const barPct = passed ? Math.min(100, (addedTb / BIG_LIMIT_TB) * 100) : 85;

  return (
    <ToolWrapper title="Облако" onClose={onClose}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col gap-4 select-none">
        {/* Уведомление поверх, не двигает интерфейс */}
        {toast && (
          <div className="rounded-2xl fixed top-20 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-sm bg-[#8f9bff] text-[#0b0d13] border border-white/25 px-4 py-3 text-[15px] pointer-events-none text-center">
            {toast}
          </div>
        )}

        {/* Объём */}
        <div className="rounded-2xl border border-white/25 p-4">
          <div className="text-[12px] uppercase tracking-[0.02em] font-medium">Хранилище:</div>
          <div className="text-[20px] mt-1 tabular-nums">
            {usedText} из {limitText}
          </div>
          <div className="rounded-2xl h-2 border border-white/25 mt-3">
            <div className="h-full bg-black" style={{ width: `${barPct}%` }} />
          </div>
        </div>

        {/* Файлы */}
        <div className="rounded-2xl border border-white/25">
          {[
            ['Документы', '0,9 КБ'],
            ['Заметки', '0,5 КБ'],
            ['Контакты', '0,3 КБ'],
          ].map(([n, sz]) => (
            <div key={n} className="rounded-2xl flex justify-between px-4 py-3 border-b border-white/10 last:border-b-0 text-[15px]">
              <span>{n}</span>
              <span className="text-gray-400 tabular-nums">{passed ? '—' : sz}</span>
            </div>
          ))}
        </div>

        <button onClick={addFile} className="rounded-2xl py-3 border border-white/25 bg-[#8f9bff] text-[#0b0d13] text-[15px] cursor-pointer">
          + Добавить файл
        </button>

        {!passed && (
          <button
            onClick={() => {
              setStage('security');
              setStep(0);
              setWrong(false);
            }}
            className="rounded-2xl py-3 border border-white/25 bg-white/[0.06] text-white text-[15px] cursor-pointer"
          >
            Увеличить объём (контроль безопасности)
          </button>
        )}

        {passed && (
          <button onClick={startTransfer} className="rounded-2xl py-3 border border-white/25 bg-white/[0.06] text-white text-[15px] cursor-pointer">
            Перенести все данные
          </button>
        )}
      </div>

      {/* Контроль безопасности */}
      {stage === 'security' && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-5">
          <div className="rounded-2xl w-full max-w-sm bg-[#151826] border border-white/15 p-5">
            <div className="flex justify-between items-baseline">
              <span className="text-[12px] uppercase tracking-[0.02em] font-medium">Контроль безопасности: {QUESTIONS[step].kind}</span>
              <span className="text-[12px] text-gray-400">
                {step + 1}/{QUESTIONS.length}
              </span>
            </div>
            <div className="text-[20px] mt-4 leading-tight">{QUESTIONS[step].text}</div>
            <div className="grid grid-cols-2 gap-2 mt-5">
              {QUESTIONS[step].options.map((o, i) => (
                <button key={i} onClick={() => answer(i)} className="rounded-2xl py-3 border border-white/25 bg-white/[0.06] text-white text-[15px] cursor-pointer hover:bg-white/10">
                  {o}
                </button>
              ))}
            </div>
            <div className="h-5 mt-3 text-[12px] text-white">{wrong ? 'Неверно. Попробуйте ещё раз.' : ''}</div>
            <button onClick={() => setStage('idle')} className="rounded-2xl mt-1 text-[15px] underline bg-transparent border-0 cursor-pointer p-0">
              Отмена
            </button>
          </div>
        </div>
      )}

      {/* Перенос данных */}
      {(stage === 'transfer' || stage === 'boom') && (
        <div className="fixed inset-0 z-50 bg-[#151826] flex items-center justify-center p-5">
          <style>{`@keyframes cl-piece { 0% { transform: translate(0,0) rotate(0); opacity: 1 } 100% { transform: translate(var(--dx),var(--dy)) rotate(var(--rot)); opacity: 0 } } @keyframes cl-flash { 0% { opacity: 1 } 100% { opacity: 0 } }`}</style>
          <div className="w-full max-w-sm">
            <div className="text-[12px] uppercase tracking-[0.02em] font-medium">Перенос данных:</div>
            <div className="text-[15px] mt-1 tabular-nums">
              {stage === 'transfer' ? `${Math.round(progress)}% · объём данных не определён` : 'Ошибка'}
            </div>

            <div className="rounded-2xl relative h-8 border border-white/25 mt-4">
              {stage === 'transfer' ? (
                <div className="h-full bg-black" style={{ width: `${progress}%` }} />
              ) : (
                Array.from({ length: 20 }).map((_, i) => (
                  <div
                    key={i}
                    className="absolute top-0 h-full bg-black"
                    style={{
                      left: `${i * 5}%`,
                      width: '5%',
                      ['--dx' as string]: `${(Math.random() - 0.5) * 520}px`,
                      ['--dy' as string]: `${(Math.random() - 0.5) * 520}px`,
                      ['--rot' as string]: `${(Math.random() - 0.5) * 720}deg`,
                      animation: 'cl-piece 1.3s ease-out forwards',
                    } as React.CSSProperties}
                  />
                ))
              )}
            </div>
          </div>
          {stage === 'boom' && <div className="fixed inset-0 bg-[#151826] z-[60] pointer-events-none" style={{ animation: 'cl-flash 0.6s ease-out forwards' }} />}
        </div>
      )}

      {/* Ошибка */}
      {stage === 'error' && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-5">
          <div className="rounded-2xl w-full max-w-sm bg-[#151826] border border-white/15 p-5">
            <div className="text-[12px] uppercase tracking-[0.02em] font-medium">Ошибка:</div>
            <div className="text-[20px] mt-2 leading-tight">Не удалось перенести данные</div>
            <p className="text-[15px] mt-3">
              Недостаточно места в облаке. Требуется 9 876 ПБ, доступно {BIG_LIMIT_TB} ТБ. Передача данных прервана.
            </p>
            <button
              onClick={() => {
                setStage('idle');
                setProgress(0);
              }}
              className="rounded-2xl mt-5 w-full py-3 border border-white/25 bg-[#8f9bff] text-[#0b0d13] text-[15px] cursor-pointer"
            >
              Закрыть
            </button>
          </div>
        </div>
      )}
    </ToolWrapper>
  );
};
