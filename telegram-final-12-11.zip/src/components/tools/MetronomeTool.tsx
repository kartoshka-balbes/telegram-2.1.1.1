import React, { useState, useEffect } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { Play, Pause, Minus, Plus } from 'lucide-react';
import { soundManager, triggerHaptic } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

const MIN_BPM = 30;
const MAX_BPM = 1000;

export const MetronomeTool: React.FC<ToolProps> = ({ onClose }) => {
  const [bpm, setBpm] = useState(120);
  const [isPlaying, setIsPlaying] = useState(false);
  const [tickRight, setTickRight] = useState(false);

  useEffect(() => {
    if (!isPlaying) return;
    const intervalMs = (60 / bpm) * 1000;
    const tick = () => {
      soundManager.playTone(1200, 0.03);
      if (bpm <= 240) triggerHaptic('tap');
      setTickRight((prev) => !prev);
    };
    tick();
    const interval = window.setInterval(tick, intervalMs);
    return () => window.clearInterval(interval);
  }, [isPlaying, bpm]);

  return (
    <ToolWrapper title="Метроном" onClose={onClose}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col items-center p-2 sm:p-4 text-center">
        <div className="bg-gradient-to-b from-[#1a1f2e] to-[#12141d] border border-white/10 rounded-[2rem] p-6 w-full shadow-[0_20px_60px_rgba(0,0,0,0.45)] flex flex-col items-center gap-6">
          {/* Маятник */}
          <div className="relative w-36 h-48 bg-black/30 border border-white/10 rounded-3xl flex items-end justify-center overflow-hidden p-4">
            <div
              className={`w-2 bg-cyan-400 rounded-full h-36 origin-bottom transition-transform ${
                isPlaying ? (tickRight ? 'rotate-30' : '-rotate-30') : 'rotate-0'
              }`}
              style={{ transitionDuration: `${Math.max(40, Math.min(250, (60 / bpm) * 1000 * 0.9))}ms` }}
            >
              <div className="w-6 h-6 bg-amber-400 rounded-full -ml-2 top-10 relative border-2 border-slate-950" />
            </div>
          </div>

          <div className="text-7xl sm:text-8xl font-extrabold text-cyan-300 tabular-nums leading-none">
            {bpm} <span className="text-lg font-semibold text-slate-500">BPM</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setBpm((b) => Math.max(MIN_BPM, b - 5))}
              className="p-3.5 bg-white/[0.06] hover:bg-white/10 border border-white/10 text-white rounded-2xl cursor-pointer active:scale-95 transition-all"
            >
              <Minus className="w-5 h-5" />
            </button>
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className={`p-5 rounded-3xl font-black cursor-pointer shadow-lg transition-transform active:scale-95 ${
                isPlaying ? 'bg-rose-500 text-white' : 'bg-gradient-to-br from-cyan-300 to-cyan-500 text-slate-950'
              }`}
            >
              {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 fill-current" />}
            </button>
            <button
              onClick={() => setBpm((b) => Math.min(MAX_BPM, b + 5))}
              className="p-3.5 bg-white/[0.06] hover:bg-white/10 border border-white/10 text-white rounded-2xl cursor-pointer active:scale-95 transition-all"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>

          <input
            type="range"
            min={MIN_BPM}
            max={MAX_BPM}
            value={bpm}
            onChange={(e) => setBpm(Number(e.target.value))}
            className="w-full cursor-pointer"
            aria-label="Темп"
          />
        </div>
      </div>
    </ToolWrapper>
  );
};
