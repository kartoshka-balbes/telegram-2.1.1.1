import React, { useState, useEffect } from 'react';
import { ToolWrapper } from './ToolWrapper';
import { YogaTool } from './YogaTool';
import { MedicalRecordTool } from './MedicalRecordTool';
import { VisionTestTool } from './VisionTestTool';
import { HearingTestTool } from './HearingTestTool';
import { MedicalNoteTool } from './MedicalNoteTool';
import { HomeWorkoutsTool } from './HomeWorkoutsTool';
import { WeightLossTool } from './WeightLossTool';
import { IMPOSSIBLE_WORKOUTS, SLEEP_EXERCISES } from '../../data/mockData';
import { Moon, Dumbbell, AlertTriangle, CheckCircle, X } from 'lucide-react';
import { soundManager } from '../../utils/soundEffects';

interface ToolProps {
  onClose: () => void;
}

const SleepScreen: React.FC<ToolProps> = ({ onClose }) => {

  // Sleep Tracker state
  const [sleepActive, setSleepActive] = useState(false);
  const [sleepSeconds, setSleepSeconds] = useState(0);
  const [sleepAlarm, setSleepAlarm] = useState<string | null>(null);

  // Sleep timer + alarm every 5s
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (sleepActive) {
      interval = setInterval(() => {
        setSleepSeconds((prev) => {
          const next = prev + 1;
          if (next % 5 === 0) {
            soundManager.playSiren();
            const ex = SLEEP_EXERCISES[Math.floor(Math.random() * SLEEP_EXERCISES.length)];
            setSleepAlarm(ex);
          }
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [sleepActive]);

  return (
    <ToolWrapper title="Здоровье: трекер сна" onClose={onClose}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col gap-6 py-4">
        {/* 1 - SLEEP TRACKER */}
        {(
          <div className="flex-1 flex flex-col items-center justify-center text-center">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 w-full shadow-xl flex flex-col items-center">
              <Moon className="w-16 h-16 text-cyan-400 mb-4 animate-pulse" />
              <div className="text-4xl font-mono font-black text-white mb-2">
                00:00:{String(sleepSeconds % 60).padStart(2, '0')}
              </div>
              <span className="text-xs text-slate-400 uppercase font-bold mb-6">
                Длительность глубокого сна
              </span>

              <button
                onClick={() => setSleepActive(!sleepActive)}
                className={`w-full py-4 rounded-2xl font-black text-lg uppercase shadow-xl transition-all cursor-pointer ${
                  sleepActive
                    ? 'bg-red-600 hover:bg-red-500 text-white'
                    : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950'
                }`}
              >
                {sleepActive ? 'Остановить трекер сна' : 'Включить трекер сна'}
              </button>
            </div>

            {/* Alarm Popup Modal */}
            {sleepAlarm && (
              <div className="fixed inset-0 bg-red-950/95 z-50 flex items-center justify-center p-6 animate-pulse">
                <div className="w-full max-w-sm bg-slate-900 border-4 border-red-500 rounded-3xl p-8 text-center shadow-2xl relative">
                  <button
                    onClick={() => setSleepAlarm(null)}
                    className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-full cursor-pointer"
                  >
                    <X className="w-6 h-6" />
                  </button>
                  <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4 animate-bounce" />
                  <h3 className="text-2xl font-black text-white uppercase mb-2">СИРЕНА ЗАРЯДКИ!</h3>
                  <p className="text-red-400 text-xs font-bold uppercase mb-4">
                    СРОЧНО ВЫПОЛНИТЕ УПРАЖНЕНИЕ:
                  </p>
                  <div className="bg-red-950 border border-red-600 rounded-2xl p-4 text-amber-300 font-black text-xl uppercase mb-6">
                    {sleepAlarm}
                  </div>
                  <button
                    onClick={() => setSleepAlarm(null)}
                    className="w-full py-3 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl uppercase cursor-pointer"
                  >
                    Выполнил!
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </ToolWrapper>
  );
};

/* ---------------- Центр здоровья ---------------- */

type SubId = 'sleep' | 'yoga' | 'medical_record' | 'vision_test' | 'hearing_test' | 'medical_note' | 'home_workouts' | 'weight_loss';

const SECTIONS: Array<{ id: SubId; title: string; sub: string; icon: string; grad: string }> = [
  { id: 'sleep', title: 'Трекер сна', sub: 'Длительность и будильник зарядки', icon: '🌙', grad: 'from-indigo-500 to-violet-500' },
  { id: 'home_workouts', title: 'Тренировки для дома', sub: 'Упражнения и видео-туториалы', icon: '🏋️', grad: 'from-orange-400 to-rose-500' },
  { id: 'weight_loss', title: 'Худеем за 30 дней', sub: 'Марафон и вкладка «Жиреем»', icon: '🔥', grad: 'from-amber-400 to-orange-500' },
  { id: 'yoga', title: 'Йога', sub: 'Позы и дыхание', icon: '🧘', grad: 'from-emerald-400 to-teal-500' },
  { id: 'medical_record', title: 'Мед. карта', sub: 'Данные и записи пациента', icon: '📋', grad: 'from-sky-400 to-blue-500' },
  { id: 'vision_test', title: 'Тест на зрение', sub: 'Проверка остроты зрения', icon: '👁️', grad: 'from-cyan-400 to-sky-500' },
  { id: 'hearing_test', title: 'Тест на слух', sub: 'Проверка слуха', icon: '👂', grad: 'from-fuchsia-400 to-pink-500' },
  { id: 'medical_note', title: 'Справка о здоровье', sub: 'Оформление справки', icon: '📝', grad: 'from-teal-400 to-cyan-500' },
];

export const HealthTool: React.FC<ToolProps> = ({ onClose }) => {
  const [sub, setSub] = useState<SubId | null>(null);
  const back = () => setSub(null);

  if (sub === 'sleep') return <SleepScreen onClose={back} />;
  if (sub === 'yoga') return <YogaTool onClose={back} />;
  if (sub === 'medical_record') return <MedicalRecordTool onClose={back} />;
  if (sub === 'vision_test') return <VisionTestTool onClose={back} />;
  if (sub === 'hearing_test') return <HearingTestTool onClose={back} />;
  if (sub === 'medical_note') return <MedicalNoteTool onClose={back} />;
  if (sub === 'home_workouts') return <HomeWorkoutsTool onClose={back} />;
  if (sub === 'weight_loss') return <WeightLossTool onClose={back} />;

  return (
    <ToolWrapper title="Здоровье" onClose={onClose}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col gap-4 py-1 select-none">
        <div className="relative overflow-hidden rounded-[2rem] p-5 border border-white/10 bg-gradient-to-br from-[#0c3b3f] via-[#0d2a45] to-[#12142b] shadow-xl">
          <div className="absolute -top-14 -right-10 w-52 h-52 rounded-full bg-teal-400/25 blur-3xl pointer-events-none" />
          <div className="relative flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/15 flex items-center justify-center text-3xl">❤️</div>
            <div>
              <h1 className="text-xl font-extrabold text-white leading-tight">Центр здоровья</h1>
              <p className="text-xs text-teal-100/80 mt-0.5">Всё о вашем здоровье в одном месте</p>
            </div>
          </div>
          <div className="relative grid grid-cols-3 gap-2 mt-4 text-center">
            {[
              ['72', 'пульс'],
              ['98%', 'сатурация'],
              ['36.6°', 'температура'],
            ].map(([n, l]) => (
              <div key={l} className="rounded-2xl bg-white/10 py-2">
                <div className="text-base font-bold text-white leading-none">{n}</div>
                <div className="text-[10px] text-teal-100/70 mt-1">{l}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2.5 pb-6">
          {SECTIONS.map((sec) => (
            <button
              key={sec.id}
              onClick={() => {
                soundManager.playBeep(900, 0.05);
                setSub(sec.id);
              }}
              className="text-left rounded-[1.5rem] bg-white/[0.05] border border-white/10 hover:border-white/25 p-3.5 flex flex-col gap-2 cursor-pointer active:scale-[0.97] transition-all"
            >
              <span className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${sec.grad} flex items-center justify-center text-2xl shadow-lg`}>{sec.icon}</span>
              <span>
                <span className="block text-[13px] font-bold text-white leading-tight">{sec.title}</span>
                <span className="block text-[10px] text-gray-400 mt-0.5 leading-snug">{sec.sub}</span>
              </span>
            </button>
          ))}
        </div>
      </div>
    </ToolWrapper>
  );
};
